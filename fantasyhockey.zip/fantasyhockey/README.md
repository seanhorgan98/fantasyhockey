# Fantasy Hockey
Welcome to the GitHub page for our fantasy hockey app.

Created by *Sean Horgan* and *Sam Owen-Hughes*.


# Notes

*When developing:* Make sure you are using a version of the JDK <11 otherwise it fucks up and won't work. Flutter doesn't support it atm.

Also if you get an error about HttpExecute when running an emulator just use a different emulator running Android Pie instead of the latest. Seemed to fix it for me.
